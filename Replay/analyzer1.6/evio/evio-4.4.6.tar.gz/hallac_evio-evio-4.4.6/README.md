# evio Software Package 4.4.6

This is a snapshot of the evio 4.4.6 release as published at:
  https://coda.jlab.org/drupal/system/files/evio-4.4.6.tgz

It is reproduced with permission in this git repository for the purposes
as a build dependence (via submodule) for the Hall A and C analyzers.

The upstream DAQ Group evio repository is private, but can be found here:
  https://github.com/JeffersonLab/evio

At some point we plan to replaces this ancilliary repo with a pointer to a
tagged release off the DAQ group's repo.

-- Brad Sawatzky <brads@jlab.org>
